from app import app, db, User, Course, Enrollment
import random
import string
from datetime import datetime, timedelta

def generate_random_name(prefix):
    # 生成随机的中文姓氏
    surnames = ['张', '王', '李', '赵', '陈', '刘', '杨', '黄', '周', '吴', 
                '郑', '孙', '马', '朱', '胡', '郭', '何', '高', '林', '罗']
    
    # 生成随机的数字后缀
    number = random.randint(1, 999)
    
    return f"{random.choice(surnames)}{prefix}{number}"

def generate_course_name():
    subjects = ['计算机', '数学', '物理', '化学', '生物', '经济', '管理', '艺术', '历史', '哲学']
    types = ['导论', '原理', '技术', '实践', '研究', '应用', '分析', '设计', '工程', '方法']
    levels = ['基础', '进阶', '高级', '专业', '综合']
    
    return f"{random.choice(subjects)}{random.choice(types)}{random.choice(levels)}"

def generate_data():
    with app.app_context():
        print("开始生成数据...")
        print("清理现有数据...")
        
        try:
            # 清空现有数据
            print("- 删除选课记录...")
            Enrollment.query.delete()
            print("- 删除课程数据...")
            Course.query.delete()
            print("- 删除用户数据（保留admin）...")
            User.query.filter(User.username != 'admin').delete()
            db.session.commit()
            print("数据清理完成！")
        except Exception as e:
            print(f"清理数据时出错: {e}")
            db.session.rollback()
            return
        
        try:
            # 生成20个教师
            print("\n开始生成教师数据...")
            teachers = []
            for i in range(20):
                username = generate_random_name('教授')
                teacher = User(username=username, role='teacher')
                teacher.set_password('teacher123')
                db.session.add(teacher)
                teachers.append(teacher)
                print(f"- 已创建教师: {username}")
            db.session.commit()
            print(f"成功创建 {len(teachers)} 个教师！")
            
            # 生成100个学生
            print("\n开始生成学生数据...")
            students = []
            for i in range(100):
                username = generate_random_name('同学')
                student = User(username=username, role='student')
                student.set_password('student123')
                db.session.add(student)
                students.append(student)
                if (i + 1) % 20 == 0:
                    print(f"- 已创建 {i + 1} 个学生")
            db.session.commit()
            print(f"成功创建 {len(students)} 个学生！")
            
            # 生成40门课程
            print("\n开始生成课程数据...")
            courses = []
            for i in range(40):
                teacher = random.choice(teachers)
                credits = random.choice([2.0, 3.0, 4.0, 5.0])
                capacity = random.randint(30, 150)
                name = generate_course_name()
                
                course = Course(
                    name=name,
                    teacher_id=teacher.id,
                    credits=credits,
                    capacity=capacity,
                    description=f"这是一门{credits}学分的课程，由{teacher.username}教授讲授。课程容量为{capacity}人。",
                    enrolled_count=0
                )
                db.session.add(course)
                courses.append(course)
                print(f"- 已创建课程: {name} (教师: {teacher.username})")
            db.session.commit()
            print(f"成功创建 {len(courses)} 门课程！")
            
            # 为80%的学生随机选课
            print("\n开始生成选课数据...")
            students_to_enroll = random.sample(students, int(len(students) * 0.8))
            total_enrollments = 0
            
            for i, student in enumerate(students_to_enroll, 1):
                # 每个学生选择2-5门课程
                num_courses = random.randint(2, 5)
                selected_courses = random.sample(courses, num_courses)
                
                for course in selected_courses:
                    enrollment = Enrollment(
                        student_id=student.id,
                        course_id=course.id,
                        created_at=datetime.now() - timedelta(days=random.randint(0, 30))
                    )
                    db.session.add(enrollment)
                    total_enrollments += 1
                    
                    # 更新课程的已选人数
                    course.enrolled_count += 1
                
                if i % 20 == 0:
                    print(f"- 已为 {i} 个学生生成选课记录")
            
            db.session.commit()
            print(f"成功为 {len(students_to_enroll)} 个学生生成了 {total_enrollments} 条选课记录！")
            
            print("\n数据生成完成！")
            print("\n默认密码：")
            print("教师密码: teacher123")
            print("学生密码: student123")
            
        except Exception as e:
            print(f"生成数据时出错: {e}")
            db.session.rollback()
            return

if __name__ == '__main__':
    generate_data() 