// 主题切换功能
document.addEventListener('DOMContentLoaded', function() {
    const savedTheme = localStorage.getItem('theme') || 'daylight';
    document.documentElement.setAttribute('data-theme', savedTheme);
    
    document.querySelectorAll('.theme-option').forEach(option => {
        if (option.dataset.theme === savedTheme) {
            option.classList.add('active');
        }
        
        option.addEventListener('click', function() {
            const theme = this.dataset.theme;
            document.documentElement.setAttribute('data-theme', theme);
            localStorage.setItem('theme', theme);
            
            document.querySelectorAll('.theme-option').forEach(opt => {
                opt.classList.remove('active');
            });
            this.classList.add('active');
        });
    });

    // 聊天功能
    const chatInput = document.querySelector('.chat-input');
    const sendButton = document.querySelector('.chat-send-btn');
    const messagesContainer = document.querySelector('.ai-chat-messages');
    const emojiButton = document.getElementById('emojiButton');
    const emojiPicker = document.querySelector('.emoji-picker');
    
    // 自动调整输入框高度
    chatInput.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 100) + 'px';
    });

    // 发送消息
    function sendMessage() {
        const message = chatInput.value.trim();
        if (message) {
            // 添加用户消息
            const userMessage = createMessage(message, true);
            messagesContainer.appendChild(userMessage);
            
            // 清空输入框
            chatInput.value = '';
            chatInput.style.height = 'auto';
            
            // 滚动到底部
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
            
            // 这里可以添加发送到后端的逻辑
            // 模拟AI回复
            setTimeout(() => {
                const aiMessage = createMessage('收到你的消息：' + message, false);
                messagesContainer.appendChild(aiMessage);
                messagesContainer.scrollTop = messagesContainer.scrollHeight;
            }, 1000);
        }
    }

    // 创建消息元素
    function createMessage(text, isUser) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `chat-message${isUser ? ' user' : ''}`;
        
        const avatar = document.createElement('div');
        avatar.className = 'chat-avatar';
        const icon = document.createElement('i');
        icon.className = isUser ? 'bi bi-person' : 'bi bi-robot';
        avatar.appendChild(icon);
        
        const bubble = document.createElement('div');
        bubble.className = 'chat-bubble';
        bubble.textContent = text;
        
        messageDiv.appendChild(avatar);
        messageDiv.appendChild(bubble);
        
        return messageDiv;
    }

    // 发送按钮点击事件
    sendButton.addEventListener('click', sendMessage);

    // 回车发送消息
    chatInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });

    // 表情选择器
    emojiButton.addEventListener('click', function() {
        emojiPicker.classList.toggle('active');
    });

    // 点击表情
    document.querySelectorAll('.emoji-item').forEach(item => {
        item.addEventListener('click', function() {
            const emoji = this.textContent;
            const start = chatInput.selectionStart;
            const end = chatInput.selectionEnd;
            const text = chatInput.value;
            
            chatInput.value = text.substring(0, start) + emoji + text.substring(end);
            chatInput.selectionStart = chatInput.selectionEnd = start + emoji.length;
            
            // 关闭表情选择器
            emojiPicker.classList.remove('active');
            chatInput.focus();
        });
    });

    // 点击外部关闭表情选择器
    document.addEventListener('click', function(e) {
        if (!emojiPicker.contains(e.target) && !emojiButton.contains(e.target)) {
            emojiPicker.classList.remove('active');
        }
    });
}); 