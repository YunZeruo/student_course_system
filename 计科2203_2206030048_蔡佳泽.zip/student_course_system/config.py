import os

# 基础配置
class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///student_course.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # 高德地图 API 配置
    AMAP_KEY = os.environ.get('AMAP_KEY') or '8325164e247e15eea68b59e89200988b'
    AMAP_WEATHER_URL = 'https://restapi.amap.com/v3/weather/weatherInfo'
    
    # 默认城市配置（可以根据实际位置修改）
    DEFAULT_CITY = '330100'  # 杭州市的城市编码 