from app import app, db, User

def init_db():
    with app.app_context():
        # 创建所有表
        db.create_all()
        
        # 检查是否已存在管理员账户
        admin = User.query.filter_by(username='admin').first()
        if not admin:
            # 创建管理员账户
            admin = User(username='admin', role='admin')
            admin.set_password('admin123')
            db.session.add(admin)
            db.session.commit()
            print('已创建管理员账户')
            print('用户名: admin')
            print('密码: admin123')
        else:
            print('管理员账户已存在')

if __name__ == '__main__':
    init_db() 