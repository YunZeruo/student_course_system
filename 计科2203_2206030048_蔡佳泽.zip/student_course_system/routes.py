from flask import render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_user, login_required, logout_user, current_user
from app import app, db
from app import User, Course, Enrollment
from weather import WeatherService
from datetime import datetime, timedelta

@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            login_user(user)
            return redirect(url_for('dashboard'))
        flash('用户名或密码错误')
    
    return render_template('login.html')

@app.route('/dashboard')
@login_required
def dashboard():
    # 基础统计数据
    total_courses = Course.query.count()
    total_students = User.query.filter_by(role='student').count()
    total_teachers = User.query.filter_by(role='teacher').count()

    # 选课人数占比数据
    enrolled_students = db.session.query(db.func.count(db.distinct(Enrollment.student_id))).scalar()
    not_enrolled_students = total_students - enrolled_students
    enrollment_percentage_data = [enrolled_students, not_enrolled_students]

    # 课程注册分布数据
    courses = Course.query.all()
    enrollment_labels = []
    enrollment_data = []
    for course in courses:
        enrollment_labels.append(course.name)
        enrollment_data.append(course.enrolled_count)

    # 教师课程统计数据
    teachers = User.query.filter_by(role='teacher').all()
    teacher_labels = []
    teacher_data = []
    for teacher in teachers:
        teacher_labels.append(teacher.username)
        teacher_data.append(len(teacher.courses))

    # 选课趋势数据（最近7天）
    trend_labels = []
    trend_data = []
    today = datetime.now().date()
    for i in range(6, -1, -1):
        date = today - timedelta(days=i)
        trend_labels.append(date.strftime('%m-%d'))
        count = Enrollment.query.filter(
            db.func.date(Enrollment.created_at) == date
        ).count()
        trend_data.append(count)

    # 课程学分分布数据
    credits_map = {}
    for course in courses:
        credit = str(course.credits)
        if credit in credits_map:
            credits_map[credit] += 1
        else:
            credits_map[credit] = 1
    credits_labels = list(credits_map.keys())
    credits_data = list(credits_map.values())

    return render_template('dashboard.html',
        total_courses=total_courses,
        total_students=total_students,
        total_teachers=total_teachers,
        enrollment_percentage_data=enrollment_percentage_data,
        enrollment_labels=enrollment_labels,
        enrollment_data=enrollment_data,
        teacher_labels=teacher_labels,
        teacher_data=teacher_data,
        trend_labels=trend_labels,
        trend_data=trend_data,
        credits_labels=credits_labels,
        credits_data=credits_data
    )

def calculate_enrollment_rate():
    total_possible = Course.query.count() * User.query.filter_by(role='student').count()
    if total_possible == 0:
        return 0
    actual_enrollments = Enrollment.query.count()
    return round((actual_enrollments / total_possible) * 100, 1)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/change_password', methods=['GET', 'POST'])
@login_required
def change_password():
    if request.method == 'POST':
        old_password = request.form.get('old_password')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')
        
        if not current_user.check_password(old_password):
            flash('当前密码错误')
        elif new_password != confirm_password:
            flash('两次输入的新密码不匹配')
        else:
            current_user.set_password(new_password)
            db.session.commit()
            flash('密码修改成功')
            return redirect(url_for('dashboard'))
    
    return render_template('change_password.html')

@app.route('/admin/add_course', methods=['GET', 'POST'])
@login_required
def add_course():
    if current_user.role != 'admin':
        flash('权限不足')
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        name = request.form.get('course_name')
        teacher = request.form.get('teacher')
        credits = float(request.form.get('credits'))
        capacity = int(request.form.get('capacity'))
        description = request.form.get('description')
        
        # 查找教师用户
        teacher_user = User.query.filter_by(username=teacher, role='teacher').first()
        if not teacher_user:
            flash('指定的教师不存在')
            return redirect(url_for('add_course'))
        
        course = Course(
            name=name,
            teacher_id=teacher_user.id,
            credits=credits,
            capacity=capacity,
            description=description,
            enrolled_count=0
        )
        db.session.add(course)
        db.session.commit()
        flash('课程添加成功')
        return redirect(url_for('manage_courses'))
    
    # 获取所有教师列表
    teachers = User.query.filter_by(role='teacher').order_by(User.username).all()
    return render_template('add_course.html', teachers=teachers)

@app.route('/course/<int:course_id>')
@login_required
def course_detail(course_id):
    course = Course.query.get_or_404(course_id)
    
    if current_user.role == 'teacher' and current_user.id == course.teacher_id:
        enrollments = Enrollment.query.filter_by(course_id=course_id).all()
        return render_template('course_detail.html', course=course, enrollments=enrollments)
    elif current_user.role == 'student':
        enrollment = Enrollment.query.filter_by(
            student_id=current_user.id,
            course_id=course_id
        ).first()
        return render_template('course_detail.html', course=course, enrollment=enrollment)
    elif current_user.role == 'admin':
        enrollments = Enrollment.query.filter_by(course_id=course_id).all()
        return render_template('course_detail.html', course=course, enrollments=enrollments)
    
    flash('权限不足')
    return redirect(url_for('dashboard'))

@app.route('/available_courses')
@login_required
def available_courses():
    if current_user.role != 'student':
        flash('权限不足')
        return redirect(url_for('dashboard'))
    
    # 获取学生未选修的课程
    enrolled_courses = Enrollment.query.filter_by(student_id=current_user.id).with_entities(Enrollment.course_id).all()
    enrolled_course_ids = [ec[0] for ec in enrolled_courses]
    available_courses = Course.query.filter(~Course.id.in_(enrolled_course_ids)).all()
    
    return render_template('available_courses.html', courses=available_courses)

@app.route('/enroll/<int:course_id>', methods=['POST'])
@login_required
def enroll_course(course_id):
    if current_user.role != 'student':
        flash('权限不足')
        return redirect(url_for('dashboard'))
    
    existing_enrollment = Enrollment.query.filter_by(
        student_id=current_user.id,
        course_id=course_id
    ).first()
    
    if existing_enrollment:
        flash('你已经选修了这门课程')
    else:
        enrollment = Enrollment(student_id=current_user.id, course_id=course_id)
        db.session.add(enrollment)
        db.session.commit()
        flash('选课成功')
    
    return redirect(url_for('dashboard'))

@app.route('/submit_grade/<int:enrollment_id>', methods=['POST'])
@login_required
def submit_grade(enrollment_id):
    if current_user.role != 'teacher':
        flash('权限不足')
        return redirect(url_for('dashboard'))
    
    enrollment = Enrollment.query.get_or_404(enrollment_id)
    course = Course.query.get(enrollment.course_id)
    
    if course.teacher_id != current_user.id:
        flash('权限不足')
        return redirect(url_for('dashboard'))
    
    grade = request.form.get('grade')
    try:
        grade = float(grade)
        if 0 <= grade <= 100:
            enrollment.grade = grade
            db.session.commit()
            flash('成绩提交成功')
        else:
            flash('成绩必须在0-100之间')
    except ValueError:
        flash('成绩格式不正确')
    
    return redirect(url_for('course_detail', course_id=course.id))

@app.route('/admin/manage_users', methods=['GET'])
@login_required
def manage_users():
    if current_user.role != 'admin':
        flash('权限不足')
        return redirect(url_for('dashboard'))
    
    users = User.query.all()
    return render_template('manage_users.html', users=users)

@app.route('/admin/add_user', methods=['POST'])
@login_required
def add_user():
    if current_user.role != 'admin':
        flash('权限不足')
        return redirect(url_for('dashboard'))
    
    username = request.form.get('username')
    password = request.form.get('password')
    role = request.form.get('role')
    
    if User.query.filter_by(username=username).first():
        flash('用户名已存在')
        return redirect(url_for('manage_users'))
    
    user = User(username=username, role=role)
    user.set_password(password)
    db.session.add(user)
    db.session.commit()
    flash('用户添加成功')
    
    return redirect(url_for('manage_users'))

@app.route('/admin/delete_user/<int:user_id>', methods=['POST'])
@login_required
def delete_user(user_id):
    if current_user.role != 'admin':
        flash('权限不足')
        return redirect(url_for('dashboard'))
    
    user = User.query.get_or_404(user_id)
    if user.role == 'admin':
        flash('不能删除管理员账户')
        return redirect(url_for('manage_users'))
    
    # 删除用户相关的选课记录
    if user.role == 'student':
        Enrollment.query.filter_by(student_id=user.id).delete()
    elif user.role == 'teacher':
        # 删除教师的课程
        courses = Course.query.filter_by(teacher_id=user.id).all()
        for course in courses:
            Enrollment.query.filter_by(course_id=course.id).delete()
            db.session.delete(course)
    
    db.session.delete(user)
    db.session.commit()
    flash('用户删除成功')
    
    return redirect(url_for('manage_users'))

@app.route('/my_courses')
@login_required
def my_courses():
    if current_user.role == 'student':
        enrollments = Enrollment.query.filter_by(student_id=current_user.id).all()
        return render_template('my_courses.html', enrollments=enrollments)
    elif current_user.role == 'teacher':
        courses = Course.query.filter_by(teacher_id=current_user.id).all()
        return render_template('my_courses.html', courses=courses)
    else:
        flash('无权访问此页面')
        return redirect(url_for('dashboard'))

@app.route('/admin/manage_courses')
@login_required
def manage_courses():
    if current_user.role != 'admin':
        flash('权限不足')
        return redirect(url_for('dashboard'))
    
    courses = Course.query.all()
    teachers = User.query.filter_by(role='teacher').all()
    return render_template('manage_courses.html', courses=courses, teachers=teachers)

@app.route('/admin/edit_course/<int:course_id>', methods=['POST'])
@login_required
def edit_course(course_id):
    if current_user.role != 'admin':
        flash('权限不足')
        return redirect(url_for('dashboard'))
    
    course = Course.query.get_or_404(course_id)
    course.name = request.form.get('name')
    teacher = request.form.get('teacher')
    
    # 查找教师用户
    teacher_user = User.query.filter_by(username=teacher, role='teacher').first()
    if not teacher_user:
        flash('指定的教师不存在')
        return redirect(url_for('manage_courses'))
    
    course.teacher_id = teacher_user.id
    course.credits = float(request.form.get('credits'))
    course.capacity = int(request.form.get('capacity'))
    course.description = request.form.get('description')
    
    db.session.commit()
    flash('课程更新成功')
    return redirect(url_for('manage_courses'))

@app.route('/admin/delete_course/<int:course_id>', methods=['POST'])
@login_required
def delete_course(course_id):
    if current_user.role != 'admin':
        flash('权限不足')
        return redirect(url_for('dashboard'))
    
    course = Course.query.get_or_404(course_id)
    
    # 删除所有相关的选课记录
    Enrollment.query.filter_by(course_id=course_id).delete()
    
    # 删除课程
    db.session.delete(course)
    db.session.commit()
    
    flash('课程删除成功')
    return redirect(url_for('manage_courses'))

@app.route('/admin/edit_user/<int:user_id>', methods=['POST'])
@login_required
def edit_user(user_id):
    if current_user.role != 'admin':
        flash('权限不足')
        return redirect(url_for('dashboard'))
    
    user = User.query.get_or_404(user_id)
    new_username = request.form.get('username')
    
    # 检查新用户名是否已存在（排除当前用户）
    existing_user = User.query.filter(User.username == new_username, User.id != user_id).first()
    if existing_user:
        flash('用户名已存在')
        return redirect(url_for('manage_users'))
    
    user.username = new_username
    user.role = request.form.get('role')
    user.is_active = 'is_active' in request.form
    
    db.session.commit()
    flash('用户信息更新成功')
    return redirect(url_for('manage_users'))

@app.route('/api/weather')
def get_weather():
    """获取天气信息的API端点"""
    try:
        weather_data = WeatherService.get_weather()
        # 添加天气图标
        weather_data['weather_icon'] = WeatherService.get_weather_icon(weather_data['weather'])
        return jsonify(weather_data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500 