from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key'  # 请在生产环境中更改此密钥
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///student_course.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# 用户模型
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # 'student', 'teacher', 'admin'
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

# 课程模型
class Course(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    teacher_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    description = db.Column(db.Text)
    credits = db.Column(db.Float, nullable=False, default=0)
    capacity = db.Column(db.Integer, nullable=False, default=0)
    enrolled_count = db.Column(db.Integer, nullable=False, default=0)
    teacher = db.relationship('User', backref='courses')

# 选课关系模型
class Enrollment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'))
    grade = db.Column(db.Float)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())
    student = db.relationship('User', backref='enrollments')
    course = db.relationship('Course', backref='enrollments')

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

def init_test_data():
    # 检查是否已经有数据
    if User.query.first() is not None:
        return
    
    # 创建管理员账户
    admin = User(username='admin', role='admin')
    admin.set_password('admin123')
    db.session.add(admin)
    
    # 创建教师账户
    teachers = [
        {'username': '张教授', 'password': 'teacher123'},
        {'username': '李教授', 'password': 'teacher123'},
        {'username': '王教授', 'password': 'teacher123'},
        {'username': '陈教授', 'password': 'teacher123'},
    ]
    
    for teacher_data in teachers:
        teacher = User(username=teacher_data['username'], role='teacher')
        teacher.set_password(teacher_data['password'])
        db.session.add(teacher)
    
    # 创建学生账户
    students = [
        {'username': '学生1', 'password': 'student123'},
        {'username': '学生2', 'password': 'student123'},
        {'username': '学生3', 'password': 'student123'},
    ]
    
    for student_data in students:
        student = User(username=student_data['username'], role='student')
        student.set_password(student_data['password'])
        db.session.add(student)
    
    db.session.commit()

# 导入路由
from routes import *

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        init_test_data()
    app.run(debug=True, port=5002) 