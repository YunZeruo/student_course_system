import requests
from flask import current_app
import json
from datetime import datetime, timedelta

class WeatherService:
    _cache = {}
    _cache_time = None
    _cache_duration = timedelta(minutes=30)  # 缓存30分钟

    @classmethod
    def get_weather(cls):
        """获取天气信息，带缓存机制"""
        now = datetime.now()
        
        # 如果缓存存在且未过期，返回缓存的数据
        if cls._cache and cls._cache_time and \
           now - cls._cache_time < cls._cache_duration:
            return cls._cache

        try:
            # 准备API请求参数
            params = {
                'key': current_app.config['AMAP_KEY'],
                'city': current_app.config['DEFAULT_CITY'],
                'extensions': 'base',
                'output': 'JSON'
            }
            
            # 发送请求
            response = requests.get(
                current_app.config['AMAP_WEATHER_URL'],
                params=params,
                timeout=5
            )
            
            # 检查响应状态
            response.raise_for_status()
            data = response.json()
            
            if data['status'] == '1' and data['lives']:
                weather_data = data['lives'][0]
                result = {
                    'temperature': weather_data['temperature'],
                    'weather': weather_data['weather'],
                    'humidity': weather_data['humidity'],
                    'winddirection': weather_data['winddirection'],
                    'windpower': weather_data['windpower'],
                    'reporttime': weather_data['reporttime']
                }
                
                # 更新缓存
                cls._cache = result
                cls._cache_time = now
                
                return result
            else:
                raise Exception('Weather API returned invalid data')
                
        except Exception as e:
            current_app.logger.error(f'Error fetching weather: {str(e)}')
            # 如果有缓存，在出错时返回缓存的数据
            if cls._cache:
                return cls._cache
            # 否则返回默认数据
            return {
                'temperature': 'N/A',
                'weather': '未知',
                'humidity': 'N/A',
                'winddirection': '未知',
                'windpower': '未知',
                'reporttime': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }

    @classmethod
    def get_weather_icon(cls, weather_desc):
        """根据天气描述返回对应的 Bootstrap 图标类名"""
        weather_icons = {
            '晴': 'bi-sun',
            '多云': 'bi-cloud-sun',
            '阴': 'bi-clouds',
            '雨': 'bi-cloud-rain',
            '雪': 'bi-snow',
            '雾': 'bi-cloud-fog',
            '霾': 'bi-cloud-haze',
            '沙尘': 'bi-wind'
        }
        
        # 遍历天气图标映射，查找最匹配的图标
        for key in weather_icons:
            if key in weather_desc:
                return weather_icons[key]
        
        # 默认返回温度计图标
        return 'bi-thermometer-half' 